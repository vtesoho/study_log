#import <Flutter/Flutter.h>

@interface YpImagePickerPlugin : NSObject<FlutterPlugin>
@end
