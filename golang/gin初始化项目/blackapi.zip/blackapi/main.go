package main

import (
	"blackapi/src/connections"
	"blackapi/src/router"
	"fmt"
)

func main() {
	connections.InitRedis()
	connections.InitMysql()
	r := router.InitRouter()
	if err := r.Run(":42351"); err != nil {
		fmt.Printf("startup service failed, err:%v\n", err)
	}

	// r := gin.Default()
	// r.GET("/ping", func(c *gin.Context) {
	// 	c.JSON(200, gin.H{
	// 		"message": "49637",
	// 	})
	// })
	// fmt.Println(config.Mysql)
	// r.Run("0.0.0.0:49637")
}
