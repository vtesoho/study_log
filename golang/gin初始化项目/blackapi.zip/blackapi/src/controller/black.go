package controller

import (
	"blackapi/src/service"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type blackApiRe struct {
	Code    int                   `json:"code"`
	Message string                `json:"message"`
	Data    service.BlackHandleRe `json:"data"`
}

func Index(c *gin.Context) {

	// now_time, _ := c.Get("now_time")
	// user_name, _ := c.Get("user_name")

	mobiles := c.PostForm("mobiles")
	sid := c.PostForm("sid")

	blackHandleRe := service.BlackHandle(mobiles, sid)

	re := blackApiRe{Code: 1, Message: "操作成功", Data: blackHandleRe}
	fmt.Println("re", re)
	// connections.Exec("hset", "test", "10564")
	// connections.BlackExec("set", "test", "10564")
	// test, _ := connections.Exec("get", "test")
	// testa, _ := connections.BlackExec("get", "test")

	// fmt.Println("test", test)
	// fmt.Println("testa", testa)

	c.JSON(http.StatusOK, re)
}
