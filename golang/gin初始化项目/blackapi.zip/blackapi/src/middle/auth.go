package middle

import (
	"blackapi/src/common"
	"blackapi/src/connections"
	"fmt"

	red "github.com/gomodule/redigo/redis"
)

func checkSid(sid string) bool {
	issid, _ := red.Bool(connections.Exec("EXISTS", sid))
	return issid

}

func checkIp(ip string) bool {

	// return true
	isWhileIp, _ := red.Int(connections.Exec("hexists", common.MemberIPKey, ip))
	if isWhileIp > 0 {
		return true
	} else {
		return false
	}
}

func checkAuth(sid string) bool {
	is_auth, _ := red.String(connections.Exec("HGET", sid, "is_auth"))
	fmt.Println("is_auth", is_auth)
	if is_auth == "1" {
		return true
	}
	if is_auth == "2" {
		return false
	}
	return false
}

func checkApi(sid string) bool {
	is_api, _ := red.String(connections.Exec("HGET", sid, "is_api"))
	if is_api == "1" {
		return true
	}
	if is_api == "2" {
		return false
	}
	return false
}
