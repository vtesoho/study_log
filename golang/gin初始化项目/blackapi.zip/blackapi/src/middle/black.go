package middle

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

func CustomRouterMiddle(c *gin.Context) {
	// t := time.Now()
	// fmt.Println("我是自定义中间件第1种定义方式---请求之前")

	ip := c.ClientIP()
	fmt.Println("ip", ip)
	if !checkIp(ip) {
		c.JSON(http.StatusOK, gin.H{
			"code":    0,
			"message": "非法ip！",
		})
		c.Abort()
		return
	}
	//在gin上下文中定义一个变量
	sid := c.PostForm("sid")

	if !checkSid(sid) {
		c.JSON(http.StatusOK, gin.H{
			"code":    0,
			"message": "会员信息不存在！",
		})
		c.Abort()
		return
	}

	if !checkAuth(sid) {
		c.JSON(http.StatusOK, gin.H{
			"code":    0,
			"message": "会员信息未认证！",
		})
		c.Abort()
		return
	}

	if !checkApi(sid) {
		c.JSON(http.StatusOK, gin.H{
			"code":    0,
			"message": "会员接口功能未开通！",
		})
		c.Abort()
		return
	}
	//请求之前
	c.Next()
	// fmt.Println("我是自定义中间件第1种定义方式---请求之后")
	//请求之后
	//计算整个请求过程耗时
	// t2 := time.Since(t)
	// log.Println(t2)

}
