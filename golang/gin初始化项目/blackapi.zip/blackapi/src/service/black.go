package service

import (
	"blackapi/src/common"
	"blackapi/src/connections"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"regexp"
	"strconv"
	"strings"

	red "github.com/gomodule/redigo/redis"
)

type phoneListType struct {
	Phone  string `json:"phone"`
	Result int    `json:"result"`
}
type BlackHandleRe struct {
	ErrorList []string        `json:"errorList"`
	PhoneList []phoneListType `json:"phoneList"`
}

func BlackHandle(mobiles string, sid string) BlackHandleRe {

	errorList := make([]string, 0)
	phoneList := make([]string, 0)
	noHandlePhoneList := make([]string, 0)
	phoneListHandle := make([]phoneListType, 0)

	mobiless := strings.Split(mobiles, ",")

	fmt.Println("mobiless", mobiless)

	for _, v := range mobiless {
		if !checkPhone(v) {
			errorList = append(errorList, v)
		} else {
			phoneList = append(phoneList, v)
		}
	}

	for _, v := range phoneList {
		if checkWhitePhone(v, sid) {
			phoneListHandle = append(phoneListHandle, phoneListType{Result: 1, Phone: v})
			continue
		}
		if checkPretty(v, sid) {
			phoneListHandle = append(phoneListHandle, phoneListType{Result: 31, Phone: v})
			continue
		}
		if checkCachePhone(v) {
			phoneListHandle = append(phoneListHandle, phoneListType{Result: 31, Phone: v})
			continue
		}
		noHandlePhoneList = append(noHandlePhoneList, v)
	}

	if len(noHandlePhoneList) > 0 {
		checkMX(noHandlePhoneList)
		fmt.Println(noHandlePhoneList)

	}

	fmt.Println("errorList", errorList)
	fmt.Println("phoneList", phoneList)
	fmt.Println("phoneListHandle", phoneListHandle)
	return BlackHandleRe{ErrorList: errorList, PhoneList: phoneListHandle}

	// $data = (isset($this->data['mobiles']) && $this->data['mobiles']) ? $this->data['mobiles'] : "";
	//     if (!$data) {
	//         error('号码不能为空！');
	//     }

	//     $data = explode(',', $data);
}

func checkPhone(phone string) bool {
	result, _ := regexp.MatchString(`^(1[3|4|5|6|7|8][0-9]\d{4,8})$`, phone)
	if result {
		return true
	} else {
		return false
	}
}

func checkWhitePhone(phone string, sid string) bool {
	is_exists, _ := red.Int(connections.Exec("hexists", sid, phone))
	if is_exists > 0 {
		return true
	} else {
		return false
	}
}

func checkPretty(phone string, sid string) bool {

	is_exists, _ := red.Int(connections.Exec("hexists", sid, "pretty"))
	if is_exists == 0 {
		return false
	}
	pretty, _ := red.String(connections.Exec("hget", sid, "pretty"))

	// str, err := json.Marshal(pretty)
	parttyMap := common.JsonToMap(pretty)
	fmt.Println("parttyMap", parttyMap)
	// test, _ := regexp.MatchString(`(\\d)\\1(\\d)\\2\$`, phone)
	// fmt.Println("parttyMap", test)
	// matched, err := regexp.MatchString(`(\\d)\\1$`, phone)
	// fmt.Println(matched, err)
	// reg, _ := regexp.Compile(`/(\\d)\\1$/g`) //AAAB
	// fmt.Println("reg", reg.FindString(phone))

	// reg, _ := regexp.Compile(`(\d)\\1(\d)\\2$`) //AA
	// reg, _ := regexp.Compile(`(\d)(\d)(\d)$`)     //AAA
	// reg, _ := regexp.Compile(`(\d)(\d)(\d)(\d)$`)     //AAAA
	// reg, _ := regexp.Compile(`(\d)(\d)(\d)(\d?)$`) //AAAB
	// reg, _ := regexp.Compile(`(\d){2,2}(\d){2,2}$`) //AAAB
	// fmt.Println("reg", reg.FindString(phone))

	for key, _ := range parttyMap {
		// fmt.Println("key", key, "value", value)

		if key == "AA" {
			if phone[len(phone)-2:len(phone)-1] == phone[len(phone)-1:] {
				// fmt.Println("AA", true)
				return true
			}
		}
		if key == "AAA" {
			last := phone[len(phone)-1:]
			if (phone[len(phone)-2:len(phone)-1] == last) && (phone[len(phone)-3:len(phone)-2] == last) {
				// fmt.Println("AAA", true)
				return true
			}
		}
		if key == "AAAA" {
			last := phone[len(phone)-1:]
			if (phone[len(phone)-2:len(phone)-1] == last) && (phone[len(phone)-3:len(phone)-2] == last) && (phone[len(phone)-4:len(phone)-3] == last) {
				// fmt.Println("AAAA", true)
				return true
			}
		}
		if key == "AAAB" {
			last := phone[len(phone)-2 : len(phone)-1]
			if (phone[len(phone)-3:len(phone)-2] == last) && (phone[len(phone)-4:len(phone)-3] == last) {
				// fmt.Println("AAAB", true)
				return true
			}
		}
		if key == "AABB" {
			a := phone[len(phone)-3 : len(phone)-2]
			b := phone[len(phone)-1:]
			if (phone[len(phone)-4:len(phone)-3] == a) && (phone[len(phone)-2:len(phone)-1] == b) {
				// fmt.Println("AABB", true)
				return true
			}
		}
		if key == "ABC" {
			a := phone[len(phone)-3 : len(phone)-2]
			b := phone[len(phone)-2 : len(phone)-1]
			c := phone[len(phone)-1:]
			aa, _ := strconv.Atoi(a)
			bb, _ := strconv.Atoi(b)
			cc, _ := strconv.Atoi(c)
			if ((cc - bb) == 1) && (bb-aa == 1) {
				// fmt.Println("ABC", true)
				return true
			}
		}
		if key == "ABCD" {
			a := phone[len(phone)-4 : len(phone)-3]
			b := phone[len(phone)-3 : len(phone)-2]
			c := phone[len(phone)-2 : len(phone)-1]
			d := phone[len(phone)-1:]
			aa, _ := strconv.Atoi(a)
			bb, _ := strconv.Atoi(b)
			cc, _ := strconv.Atoi(c)
			dd, _ := strconv.Atoi(d)
			if ((aa - bb) == 1) && (bb-cc == 1) && (cc-dd == 1) {
				// fmt.Println("ABCD", true)
				return true
			}
		}
		if key == "ABCDABCD" {
			a := phone[len(phone)-4 : len(phone)-3]
			b := phone[len(phone)-3 : len(phone)-2]
			c := phone[len(phone)-2 : len(phone)-1]
			d := phone[len(phone)-1:]
			aa, _ := strconv.Atoi(a)
			bb, _ := strconv.Atoi(b)
			cc, _ := strconv.Atoi(c)
			dd, _ := strconv.Atoi(d)
			if ((dd - cc) == 1) && (cc-bb == 1) && (bb-aa == 1) && (d == phone[len(phone)-5:len(phone)-4]) {
				// fmt.Println("ABCDABCD", true)
				return true
			}
		}
	}
	return false

	// red.Int(connections.Exec("hget", sid, ""))
}

func checkCachePhone(phone string) bool {
	key := phone[0:3]
	is_exists, _ := red.Int(connections.Exec("hexists", key, phone))
	if is_exists > 0 {
		return true
	} else {
		return false
	}

}

type AutoGenerated struct {
	Count int    `json:"count"`
	Data  []Data `json:"data"`
}
type Data struct {
	Phone  string `json:"phone"`
	Result int    `json:"result"`
	Msg    string `json:"msg"`
}

func checkMX(phones []string) {
	phonesHandle := common.ArrayToString(phones, "|")
	// fmt.Println("test", test)
	resp, err := http.Post("http://101.132.99.164:3000/Api/blackcheckjsonMulti/204/09c311b8b039e7c6ce9aedb4cd3145d6",
		"application/x-www-form-urlencoded",
		strings.NewReader(phonesHandle))
	if err != nil {
		fmt.Println(err)
	}

	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	fmt.Println(string(body))

	var re AutoGenerated

	json.Unmarshal(body, &re)

	if re.Count > 0 {
		for _, v := range re.Data {
			if v.Result != 1 {
				key := v.Phone[0:3]
				red.Bool(connections.Exec("hget", key, v.Phone))
			}
		}
	}

	// for k, v := range re {
	// }

	if err != nil {
		// handle error
	}
}
