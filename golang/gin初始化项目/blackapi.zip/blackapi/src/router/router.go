package router

import (
	"blackapi/src/controller"
	"blackapi/src/middle"

	"github.com/gin-gonic/gin"
)

func InitRouter() *gin.Engine {
	router := gin.Default()
	router.Use(middle.CustomRouterMiddle)
	router.POST("api/blacklist", controller.Index)
	return router
}
