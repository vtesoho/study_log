package connections

import (
	"blackapi/src/conf"
	"fmt"
	"time"

	red "github.com/gomodule/redigo/redis"
)

type Redis struct {
	pool *red.Pool
}

var redis *Redis

func InitRedis() {
	redis = new(Redis)
	redis.pool = &red.Pool{
		MaxIdle:     1000,
		MaxActive:   3000,
		IdleTimeout: 240 * time.Second,
		Dial: func() (red.Conn, error) {
			return red.Dial(
				"tcp",
				conf.GetEnv().BlackRedisAddr,
				red.DialReadTimeout(time.Duration(1000)*time.Millisecond),
				red.DialWriteTimeout(time.Duration(1000)*time.Millisecond),
				red.DialConnectTimeout(time.Duration(1000)*time.Millisecond),
				red.DialDatabase(conf.GetEnv().BlackRedisDb),
				red.DialPassword(conf.GetEnv().BlackRedisPassword),
			)
		},
	}
}

func Exec(cmd string, key interface{}, args ...interface{}) (interface{}, error) {
	con := redis.pool.Get()
	if err := con.Err(); err != nil {
		return "", err
	}
	defer con.Close()
	parmas := make([]interface{}, 0)
	parmas = append(parmas, key)
	if len(args) > 0 {
		for _, v := range args {
			parmas = append(parmas, v)
		}
	}
	fmt.Println("cmd", cmd, "parmas", parmas)
	return con.Do(cmd, parmas...)
}
