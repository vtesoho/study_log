package connections

import (
	"database/sql"
	"log"
)

func InitMysql() {
	// 'driver' => 'mysql',
	// 'host' => env('DB_HOST', '8.129.221.136'),
	// 'port' => env('DB_PORT', 3306),
	// 'database' => env('DB_DATABASE', 'admin'),
	// 'username' => env('DB_USERNAME', 'admin'),
	// 'password' => env('DB_PASSWORD', 'EDa8jzZ4w3LK8Wcf'),
	// 'unix_socket' => env('DB_SOCKET', ''),
	// 'charset' => env('DB_CHARSET', 'utf8mb4'),
	// 'collation' => env('DB_COLLATION', 'utf8mb4_unicode_ci'),
	// 'prefix' => env('DB_PREFIX', 'web_'),
	// 'strict' => env('DB_STRICT_MODE', true),
	// 'engine' => env('DB_ENGINE', null),
	// 'timezone' => env('DB_TIMEZONE', '+00:00'),
	db, err := sql.Open("mysql", "admin:EDa8jzZ4w3LK8Wcf@tcp(8.129.221.136:3306)/admin")
	if err != nil {
		log.Fatalln(err)
	}
	defer db.Close()

	db.SetMaxIdleConns(20)
	db.SetMaxOpenConns(20)

	if err := db.Ping(); err != nil {
		log.Fatalln(err)
	}

}
