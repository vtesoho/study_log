package conf

import "github.com/go-sql-driver/mysql"

// 本文件建议在代码协同工具(git/svn等)中忽略

var env = Env{
	Debug: true,

	ServerPort: "服务端口",

	Database: mysql.Config{
		User:                 "用户名",
		Passwd:               "密码",
		Addr:                 "IP地址:端口",
		DBName:               "数据库名",
		Collation:            "utf8mb4_unicode_ci",
		Net:                  "tcp",
		AllowNativePasswords: true,
	},
	MaxIdleConns: 50,
	MaxOpenConns: 100,

	RedisAddr:     "127.0.0.1:6379",
	RedisPort:     "6379",
	RedisPassword: "skbYSbXcYv5dhX2NM38DpaQB3ECyzPqa",
	RedisDb:       0,

	RedisSessionDb: 1,
	RedisCacheDb:   2,

	BlackRedisAddr:     "172.24.119.133:6379",
	BlackRedisPort:     "6379",
	BlackRedisPassword: "Lgkzjl!@#2013..",
	BlackRedisDb:       0,

	AccessLog:     true,
	AccessLogPath: "storage/logs/access.log",

	ErrorLog:     true,
	ErrorLogPath: "storage/logs/error.log",

	InfoLog:     true,
	InfoLogPath: "storage/logs/info.log",

	TemplatePath: "frontend/templates",

	//APP_SECRET: "YbskZqLNT6TEVLUA9HWdnHmZErypNJpL",
	AppSecret:     "something-very-secret",
	EsearchServer: "",
}
