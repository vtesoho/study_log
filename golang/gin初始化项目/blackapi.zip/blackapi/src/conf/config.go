package conf

import "github.com/go-sql-driver/mysql"

// 环境配置文件
// 可配置多个环境配置，进行切换

type Env struct {
	Debug          bool
	Database       mysql.Config
	MaxIdleConns   int
	MaxOpenConns   int
	ServerPort     string
	RedisAddr      string
	RedisPort      string
	RedisPassword  string
	RedisDb        int
	RedisSessionDb int
	RedisCacheDb   int
	AppSecret      string

	BlackRedisAddr     string
	BlackRedisPort     string
	BlackRedisPassword string
	BlackRedisDb       int

	AccessLog     bool
	AccessLogPath string
	ErrorLog      bool
	ErrorLogPath  string
	InfoLog       bool
	InfoLogPath   string

	SqlLog bool

	TemplatePath  string // 静态文件相对路径
	EsearchServer string
}

func GetEnv() *Env {
	return &env
}
