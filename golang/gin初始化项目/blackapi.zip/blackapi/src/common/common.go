package common

import "encoding/json"

var MemberRedisKey = "member_cache"
var MemberIPKey = "member_ip_cache"

func JsonToMap(str string) map[string]interface{} {
	//map 转json

	var tempMap map[string]interface{}
	err := json.Unmarshal([]byte(str), &tempMap)

	if err != nil {
		panic(err)
	}

	return tempMap
}

func ArrayToString(arr []string, separate string) string {

	var result string

	for _, i := range arr { //遍历数组中所有元素追加成string

		result += i
		result += separate

	}

	return result[0 : len(result)-1]

}
